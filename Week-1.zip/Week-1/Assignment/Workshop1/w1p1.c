/*****************************************************************************
<assessment name example : Workshop - #1 (Part - 1)>
Full Name :Ali Riza Sevgili
Student ID# :arsevgili
	Email :arsevgili@myseneca.ca
	Section :NGG
	Authenticity Declaration :
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider.This submitted
piece of work is entirely of my own creation.
* ****************************************************************************/
#include <stdio.h>

int main(vo�d) {

	printf("Workshop 1 Part-1\n");
	printf("=================\n\n");
	printf("I'm displaying this using the 'printf' stdio\n");
	printf("(standart input output) library function!\n\n");
	printf("Dear teacher, \n\n");
	printf(" I promise I will work hard from this day onward.\n");
	printf("I acknowledge that practice is extremly important,\n");
	printf("so I will do all workshop, quizzes, and assignments.\n");
	printf("Sincerly,\n\n");
	printf("Ali Riza Sevgili\n");
	printf("Student ID 138200228\n");
	return 0;



}